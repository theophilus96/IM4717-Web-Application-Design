var myname = document.getElementById("myName");
var email = document.getElementById("myEmail");
var mydate = document.getElementById("myDateid");
//var comments = document.getElementById("myComments");

myname.addEventListener("change", checkname,false);
email.addEventListener("change", checkemail,false);
mydate.addEventListener("change", checkdate,false);
//comments.addEventListener("change", checkcomments,false);