var javaqty = document.getElementById("javaqty");
var javasum = document.getElementById("javasum");
var cafeqty = document.getElementById("cafeqty");
var cafesum = document.getElementById("cafesum");
//var caferadio = document.getElementById("Caferadio");
var cappuqty = document.getElementById("cappuqty");
var cappusum = document.getElementById("cappusum");
var totalsum = document.getElementById("totalsum");

//var comments = document.getElementById("myComments");

javaqty.addEventListener("change", javalistener, false);
cafeqty.addEventListener("change", cafelistener, false);
//caferadio.addEventListener("change", caferadiolistener, false);
cappuqty.addEventListener("change", cappulistener, false);
totalsum.addEventListener("change", totallistener, false);
//comments.addEventListener("change", checkcomments,false);
