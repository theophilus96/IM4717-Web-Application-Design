<?php
Define ('TIREPRICE', 100);
Define ('oilprice', 10);
Define ('SPARKPRICE', 4);

echo TIREPRICE;
echo "<br>";
echo oilprice;
?>