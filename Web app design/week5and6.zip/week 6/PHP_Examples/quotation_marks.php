<?php
//stringquotes.php
$fn = "James";
$ln = 'bond';
echo 'Double quotes: "James" <br>';
echo "Single quote: 'bond' <br>";
echo $fn    . " " . $ln;
?>