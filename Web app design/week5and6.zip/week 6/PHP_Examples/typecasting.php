<?php
$varname = 'tireqty';
$$varname = 5;
echo $tireqty;
?>