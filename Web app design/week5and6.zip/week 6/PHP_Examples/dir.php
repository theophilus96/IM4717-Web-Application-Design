<?php
$out=`ls -l`;
echo "<pre>" .$out. "</pre>";
?>